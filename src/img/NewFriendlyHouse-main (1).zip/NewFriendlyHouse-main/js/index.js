import { sara } from './sara.js';
import { form } from './form.js';
import { burger } from './burger.js';

sara();
form();
burger();